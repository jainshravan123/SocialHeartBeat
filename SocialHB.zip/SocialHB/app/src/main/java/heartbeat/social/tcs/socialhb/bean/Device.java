package heartbeat.social.tcs.socialhb.bean;

/**
 * Created by admin on 18/07/16.
 */
public class Device
{

    private String deviceType;
    private String deviceMacId;

    public String getDeviceType() {
        return deviceType;
    }
    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }
    public String getDeviceMacId() {
        return deviceMacId;
    }
    public void setDeviceMacId(String deviceMacId) {
        this.deviceMacId = deviceMacId;
    }



}
