package heartbeat.social.tcs.socialhb.bean;

/**
 * Created by admin on 18/07/16.
 */
public class Web_API_Config
{


    public static String root_domain_url                =           "https://socialheartbeat-bloggie.rhcloud.com/api/";
    public static String root_image_url                 =           "https://socialheartbeat-bloggie.rhcloud.com/api/";

    public static String user_login_api                 =           root_domain_url + "users/login";
    public static String user_basic_info                =           root_domain_url + "users/";
    public static String user_profile_api               =           root_domain_url + "users/profile/";
    public static String enabled_modules                =           root_domain_url + "modules";
    public static String csr_init_enabled_modules       =           root_domain_url + "csrInitCategories";
    public static String csr_init_category_data         =           root_domain_url + "csrInitCategories/cat_data/";

    public static String utility_enabled_module         =           root_domain_url + "utility/enabledCategory";

    public static String user_profile_update_api        =           root_domain_url + "users/profile/updateProfile";
    public static String user_profile_pic_update_api    =           root_domain_url + "";

    public static String donate_item                    =           root_domain_url + "donate/donateItem";



    public static String without_signin_firebase_push_notification_API  =   root_domain_url + "notify/regiterTokenBeforeSignIn";
    public static String firebase_push_notification_API                 =   root_domain_url + "notify/regiterToken";

    public static String firebase_update_user_id_for_registered_token_API    = root_domain_url + "notify/updateUserIDAfterSignIn";


}
