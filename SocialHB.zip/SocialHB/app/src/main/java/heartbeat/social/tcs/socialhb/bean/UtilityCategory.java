package heartbeat.social.tcs.socialhb.bean;

/**
 * Created by admin on 26/07/16.
 */
public class UtilityCategory
{

    private int id;
    private String utility_cat_name;
    private int status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUtility_cat_name() {
        return utility_cat_name;
    }

    public void setUtility_cat_name(String utility_cat_name) {
        this.utility_cat_name = utility_cat_name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
