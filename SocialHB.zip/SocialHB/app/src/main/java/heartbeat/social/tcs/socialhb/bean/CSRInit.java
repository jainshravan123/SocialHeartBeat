package heartbeat.social.tcs.socialhb.bean;

/**
 * Created by admin on 22/07/16.
 */
public class CSRInit
{

    private int csr_module_id;
    private String csr_module_name;
    private String csr_module_icon;
    private int csr_module_status;
    private int csr_module_icon_id;

    public int getCsr_module_id() {
        return csr_module_id;
    }

    public void setCsr_module_id(int csr_module_id) {
        this.csr_module_id = csr_module_id;
    }

    public String getCsr_module_name() {
        return csr_module_name;
    }

    public void setCsr_module_name(String csr_module_name) {
        this.csr_module_name = csr_module_name;
    }

    public String getCsr_module_icon() {
        return csr_module_icon;
    }

    public void setCsr_module_icon(String csr_module_icon) {
        this.csr_module_icon = csr_module_icon;
    }

    public int getCsr_module_status() {
        return csr_module_status;
    }

    public void setCsr_module_status(int csr_module_status) {
        this.csr_module_status = csr_module_status;
    }

    public int getCsr_module_icon_id() {
        return csr_module_icon_id;
    }

    public void setCsr_module_icon_id(int csr_module_icon_id) {
        this.csr_module_icon_id = csr_module_icon_id;
    }
}
