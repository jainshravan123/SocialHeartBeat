package heartbeat.social.tcs.socialhb.bean;

/**
 * Created by admin on 25/07/16.
 */
public class UserProfile
{

    private int id;
    private int user_id;
    private String emp_id;
    private String first_name;
    private String last_name;
    private String home_contact_number;
    private String home_country_code;
    private String work_contact_number;
    private String work_country_code;
    private String official_email;
    private String personal_email;
    private String resedential_add;
    private String offc_add;
    private String profile_image;
    private String profile_back_image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(String emp_id) {
        this.emp_id = emp_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getHome_contact_number() {
        return home_contact_number;
    }

    public void setHome_contact_number(String home_contact_number) {
        this.home_contact_number = home_contact_number;
    }

    public String getHome_country_code() {
        return home_country_code;
    }

    public void setHome_country_code(String home_country_code) {
        this.home_country_code = home_country_code;
    }

    public String getWork_contact_number() {
        return work_contact_number;
    }

    public void setWork_contact_number(String work_contact_number) {
        this.work_contact_number = work_contact_number;
    }

    public String getWork_country_code() {
        return work_country_code;
    }

    public void setWork_country_code(String work_country_code) {
        this.work_country_code = work_country_code;
    }

    public String getOfficial_email() {
        return official_email;
    }

    public void setOfficial_email(String official_email) {
        this.official_email = official_email;
    }

    public String getPersonal_email() {
        return personal_email;
    }

    public void setPersonal_email(String personal_email) {
        this.personal_email = personal_email;
    }

    public String getResedential_add() {
        return resedential_add;
    }

    public void setResedential_add(String resedential_add) {
        this.resedential_add = resedential_add;
    }

    public String getOffc_add() {
        return offc_add;
    }

    public void setOffc_add(String offc_add) {
        this.offc_add = offc_add;
    }

    public String getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(String profile_image) {
        this.profile_image = profile_image;
    }

    public String getProfile_back_image() {
        return profile_back_image;
    }

    public void setProfile_back_image(String profile_back_image) {
        this.profile_back_image = profile_back_image;
    }
}
