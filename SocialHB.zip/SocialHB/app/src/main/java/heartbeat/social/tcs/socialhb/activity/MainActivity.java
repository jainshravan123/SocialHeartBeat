package heartbeat.social.tcs.socialhb.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import heartbeat.social.tcs.socialhb.R;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
